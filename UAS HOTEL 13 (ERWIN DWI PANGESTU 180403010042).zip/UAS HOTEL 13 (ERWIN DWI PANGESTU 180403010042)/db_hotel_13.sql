-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Jan 2020 pada 14.53
-- Versi server: 10.1.32-MariaDB
-- Versi PHP: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hotel_13`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kamar`
--

CREATE TABLE `tb_kamar` (
  `noruang` int(11) NOT NULL,
  `tarif` double DEFAULT NULL,
  `tipe` varchar(20) DEFAULT NULL,
  `fasilitas` varchar(10) DEFAULT NULL,
  `kapastitas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_kamar`
--

INSERT INTO `tb_kamar` (`noruang`, `tarif`, `tipe`, `fasilitas`, `kapastitas`) VALUES
(101, 2000, 'deluxe', 'ac', 2),
(102, 2500, 'deluxe', 'ac', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_karyawan`
--

CREATE TABLE `tb_karyawan` (
  `idkaryawan` int(50) NOT NULL,
  `Nama` varchar(255) DEFAULT NULL,
  `alamat` text,
  `notelepon` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_karyawan`
--

INSERT INTO `tb_karyawan` (`idkaryawan`, `Nama`, `alamat`, `notelepon`) VALUES
(101, 'genta', 'malang', 82233334444),
(102, 'zafran', 'sampit', 83344445555);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `idpelanggan` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jk` varchar(20) DEFAULT NULL,
  `alamat` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`idpelanggan`, `Email`, `Password`, `nama`, `jk`, `alamat`) VALUES
(31, 'soleh@gmail.com', 'soleh123', 'soleh', 'm', 'padang'),
(32, 'gofar@gmail.com', 'gofar123', 'gofar', 'm', 'medan'),
(33, 'danila@gmail.com', 'danila123', 'danila', 'f', 'aceh');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_resepsionis`
--

CREATE TABLE `tb_resepsionis` (
  `idkaryawan` int(11) DEFAULT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Shift` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_resepsionis`
--

INSERT INTO `tb_resepsionis` (`idkaryawan`, `Email`, `Password`, `Shift`) VALUES
(102, 'devika@gmail.com', '123', 'Morning');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_reservasi`
--

CREATE TABLE `tb_reservasi` (
  `idbooking` int(11) NOT NULL,
  `idpelanggan` int(11) DEFAULT NULL,
  `noruang` int(11) DEFAULT NULL,
  `Checkin` date NOT NULL,
  `Checkout` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_reservasi`
--

INSERT INTO `tb_reservasi` (`idbooking`, `idpelanggan`, `noruang`, `Checkin`, `Checkout`) VALUES
(41, 31, 102, '2016-10-11', '2016-10-14'),
(42, 31, 102, '2016-10-11', '2016-10-13'),
(43, 31, 102, '2016-10-18', '2016-10-22'),
(46, 31, 101, '2016-10-19', '2016-10-20'),
(56, 31, 101, '2016-10-18', '2016-10-19'),
(58, 31, 102, '2016-10-27', '2016-10-28'),
(59, 31, 102, '2016-10-26', '2016-10-27'),
(60, 31, 102, '2016-10-24', '2016-10-26'),
(61, 31, 102, '2016-10-24', '2016-10-26'),
(62, 31, 102, '2016-10-24', '2016-10-26'),
(63, 31, 102, '2016-10-24', '2016-10-26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tagihan`
--

CREATE TABLE `tb_tagihan` (
  `notagihan` int(11) NOT NULL,
  `idpelanggan` int(11) DEFAULT NULL,
  `noruang` int(11) DEFAULT NULL,
  `tarif` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_tagihan`
--

INSERT INTO `tb_tagihan` (`notagihan`, `idpelanggan`, `noruang`, `tarif`) VALUES
(5, 31, 101, 2000),
(6, 31, 101, 2000),
(7, 31, 102, 2500),
(8, 31, 102, 2500),
(9, 31, 102, 2500),
(10, 31, 102, 2500),
(11, 31, 102, 2500),
(12, 31, 102, 2500);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_kamar`
--
ALTER TABLE `tb_kamar`
  ADD PRIMARY KEY (`noruang`);

--
-- Indeks untuk tabel `tb_karyawan`
--
ALTER TABLE `tb_karyawan`
  ADD PRIMARY KEY (`idkaryawan`);

--
-- Indeks untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`idpelanggan`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indeks untuk tabel `tb_resepsionis`
--
ALTER TABLE `tb_resepsionis`
  ADD KEY `EmpID` (`idkaryawan`);

--
-- Indeks untuk tabel `tb_reservasi`
--
ALTER TABLE `tb_reservasi`
  ADD PRIMARY KEY (`idbooking`),
  ADD KEY `CustID` (`idpelanggan`),
  ADD KEY `Roomno` (`noruang`);

--
-- Indeks untuk tabel `tb_tagihan`
--
ALTER TABLE `tb_tagihan`
  ADD PRIMARY KEY (`notagihan`),
  ADD KEY `CustID` (`idpelanggan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `idpelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_resepsionis`
--
ALTER TABLE `tb_resepsionis`
  ADD CONSTRAINT `tb_resepsionis_ibfk_1` FOREIGN KEY (`idkaryawan`) REFERENCES `tb_karyawan` (`idkaryawan`);

--
-- Ketidakleluasaan untuk tabel `tb_reservasi`
--
ALTER TABLE `tb_reservasi`
  ADD CONSTRAINT `Foreign Key` FOREIGN KEY (`idpelanggan`) REFERENCES `tb_pelanggan` (`idpelanggan`),
  ADD CONSTRAINT `Foreign Key 2` FOREIGN KEY (`noruang`) REFERENCES `tb_kamar` (`noruang`);

--
-- Ketidakleluasaan untuk tabel `tb_tagihan`
--
ALTER TABLE `tb_tagihan`
  ADD CONSTRAINT `tb_tagihan_ibfk_1` FOREIGN KEY (`idpelanggan`) REFERENCES `tb_pelanggan` (`idpelanggan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
